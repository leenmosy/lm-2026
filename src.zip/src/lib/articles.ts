export interface Product {
  id: number;
  title: string;
  description: string;
  image: string;
  price: string;
  affiliateUrl: string;
  why: string;
  marketplace: string;
}

export interface Article {
  slug: string;
  title: string;
  description: string;
  coverImage: string;
  date: string;
  tags: string[];
  category: string;
  featured: boolean;
  readingTime: number;
  order: number;
  intro: string;
  products: Product[];
  conclusion: string;
  popular: boolean;
}

const articles: Article[] = [

  {
  popular: true,
  slug: '5-veshchey-kotorye-delayut-spalnyu-vizualno-dorozhe',
  title: '5 вещей, которые делают спальню визуально дороже',
  description: 'Без ремонта - только детали, которые делают интерьер более дорогим, спокойным и уютным на вид.',
  coverImage: '/images/5-veshchey-kotorye-delayut-spalnyu-vizualno-dorozhe/cover.jpg',
  date: '2026-05-15',
  tags: ['спальня', 'уют', 'декор', 'без ремонта'],
  category: 'Спальня',
  featured: true,
  readingTime: 5,
  order: 5,
  intro: `Спальня - это место, где атмосфера ощущается сильнее всего.
  Даже дорогой ремонт не особо помогает, если комната выглядит пусто и неуютно.
  И наоборот - иногда хватает пары правильных деталей, чтобы пространство воспринималось совсем иначе. 
  И самое приятное, что такие изменения не требуют больших затрат. Здесь все решают не цена вещей, а текстуры, свет и ощущение порядка в комнате.`,
  products: [
    {
      id: 1,
      title: 'Декоративная наволочка',
      description: 'Декоративная наволочка добавляет кровати объём и делает интерьер более живым, даже если в комнате почти нет других вещей.',
      image: '/images/5-veshchey-kotorye-delayut-spalnyu-vizualno-dorozhe/product-01.webp',
      price: 'от 500 ₽',
      affiliateUrl: 'https://market.yandex.ru/cc/9SECWV',
      why: 'Рельефная ткань даёт ощущение глубины и уюта, поэтому спальня выглядит аккуратнее и дороже. Лучше всего смотрятся спокойные оттенки - молочный, бежевый, серый или нежно-голубой.',
      marketplace: 'Yandex',
    },
    {
      id: 2,
      title: 'Настольная лампа-светильник',
      description: 'Настольная лампа-светильник создаёт локальный мягкий свет, который сразу делает пространство более тёплым и «собранным».',
      image: '/images/5-veshchey-kotorye-delayut-spalnyu-vizualno-dorozhe/product-02.webp',
      price: 'от 1 500 ₽',
      affiliateUrl: 'https://market.yandex.ru/cc/9SECKB',
      why: 'Тёплое рассеянное освещение убирает резкие тени и добавляет ощущение уюта. Такая лампа работает как акцентный источник света и визуально делает интерьер более дорогим и спокойным, особенно в вечернее время.',
      marketplace: 'Yandex',
    },
    {
      id: 3,
      title: 'Бра-светильник настенный',
      description: 'Бра-светильник настенный добавляет интерьеру мягкий боковой свет и помогает формировать атмосферу без перегрузки пространства лишними источниками освещения.',
      image: '/images/5-veshchey-kotorye-delayut-spalnyu-vizualno-dorozhe/product-03.webp',
      price: 'от 700 ₽',
      affiliateUrl: 'https://market.yandex.ru/cc/9SEC9o',
      why: 'Настенное освещение создаёт глубину и объём в комнате, подчёркивая текстуры и детали интерьера. Тёплый рассеянный свет делает спальню более уютной и визуально «дорогой», особенно в зонах отдыха у кровати или зеркала.',
      marketplace: 'Yandex',
    },
    {
      id: 4,
      title: 'Стильный диффузор',
      description: 'Диффузор для дома создаёт стабильный фоновый аромат, который формирует ощущение чистоты и завершённости пространства.',
      image: '/images/5-veshchey-kotorye-delayut-spalnyu-vizualno-dorozhe/product-04.webp',
      price: 'от 300 ₽',
      affiliateUrl: 'https://market.yandex.ru/cc/9SEBnB',
      why: 'Аромат работает как невидимый слой интерьера: он влияет на восприятие комнаты не через визуал, а через атмосферу. Лёгкий и равномерный запах делает помещение более уютным, спокойным и «собранным», особенно в жилых зонах.',
      marketplace: 'Yandex',
    },
    {
      id: 5,
      title: 'Интерьерный поднос',
      description: 'Интерьерный поднос помогает собрать мелкие предметы в одну визуально организованную композицию и убрать ощущение хаоса на поверхности.',
      image: '/images/5-veshchey-kotorye-delayut-spalnyu-vizualno-dorozhe/product-05.webp',
      price: 'от 350 ₽',
      affiliateUrl: 'https://market.yandex.ru/cc/9SECjf',
      why: 'Когда предметы собраны на подносе, появляется ощущение порядка и продуманного интерьера. Даже простые вещи как свечи, диффузор, украшения - начинают выглядеть как единая композиция и добавляют пространству аккуратность и структуру.',
      marketplace: 'Yandex',
    },
  ],
  conclusion: `Дорогая спальня - это редко про стоимость мебели. Обычно все решает ощущение уюта,
  порядка и того, что пространство выглядит продуманным. Иногда достаточно просто поменять текстиль и освещение,
  чтобы спальня воспринималась совсем по-другому.`,
  },
  
];

export function getAllArticles(): Article[] {
  return [...articles].sort((a, b) => a.order - b.order);
}

export function getArticleBySlug(slug: string): Article | undefined {
  return articles.find((article) => article.slug === slug);
}

export function getFeaturedArticle(): Article | undefined {
  return articles.find((article) => article.featured);
}

export function getArticlesSortedByDate(): Article[] {
  return [...articles].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );
}

export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('ru-RU', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

export function formatDateShort(dateString: string): string {
  const date = new Date(dateString);
  return date.getFullYear().toString();
}

export function getPopularArticles(): Article[] {
  return articles.filter(a => a.popular);
}